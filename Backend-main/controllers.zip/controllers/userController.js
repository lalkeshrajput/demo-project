// const User = require('../models/user');

// exports.createUser = async (req, res) => {
//   try {
//     const user = await User.create(req.body);
//     res.status(201).json(user);
//   } catch (err) {
//     res.status(400).json({ error: err.message });
//   }
// };

// exports.getAllUsers = async (req, res) => {
//   try {
//     const users = await User.find();
//     res.status(200).json(users);
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// };
const User = require('../models/user');

exports.createUser = async (req, res) => {
  try {
    const user = await User.create(req.body);
    res.status(201).json(user);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getUsers = async (req, res) => {
  try {
    const users = await User.find();
    const text = users.map(user =>
      `Name: ${user.name}\nEmail: ${user.email}\nPhone: ${user.phone}\nAddress: ${user.address}`
    ).join('\n');

    res.set('Content-Type', 'text/plain');
    res.send(text);
  } catch (err) {
    res.status(500).send('Error fetching users');
  }
};

